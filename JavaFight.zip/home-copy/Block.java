public class Block extends Move {

    public Block() {
        super("Block");
    }

    public void performMove(Player player, Player opponent, Move opponentMove, Referee referee) {
    //The logic is in other move classes.
    }
}
